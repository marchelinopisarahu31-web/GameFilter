# Game Filter

Filter warna untuk seluruh layar (termasuk game), mirip ReShade, dengan UI ala editor media:
Filters (16 preset + Intensity sampai 300%) dan Adjust (Brightness, Contrast, Saturation, Exposure,
Vibrance, Warmth, Tint, Hue, Fade, rentang sampai +-300).

## Cara kerja
Layar sebenarnya diubah lewat matriks warna SurfaceFlinger (`service call SurfaceFlinger 1015`).
Ini butuh hak shell, jadi app memakai **Shizuku** (tanpa root) atau **root**.
Efek tetap aktif walau app ditutup. Tile "Game filter" di Quick Settings bisa menyalakan/mematikan.

## Tes dulu apakah HP kamu mendukung (tanpa build apa pun)
Sambungkan HP ke PC dengan USB debugging, lalu:

    adb shell service call SurfaceFlinger 1015 i32 1 f 0.3 f 0.3 f 0.3 f 0 f 0.59 f 0.59 f 0.59 f 0 f 0.11 f 0.11 f 0.11 f 0 f 0 f 0 f 0 f 1

Kalau layar jadi hitam-putih, HP kamu mendukung. Kembalikan dengan:

    adb shell service call SurfaceFlinger 1015 i32 0

Kalau tidak ada perubahan, cara ini diblokir di HP/ROM kamu dan app tidak akan bekerja.

## Build
1. Buka folder ini di Android Studio (Koala atau lebih baru), tunggu Gradle sync.
2. Run ke HP, atau Build > Build APK(s).
3. Pasang Shizuku dari Play Store/GitHub, nyalakan lewat Wireless debugging, lalu buka Game Filter
   dan ketuk status di bawah judul untuk memberi izin Shizuku.
4. Pilih filter, tekan Apply.

## Batasan
- Hanya efek berbasis matriks warna (linear). Highlights/Shadows, Gamma, Sharpness, Vignette, Grain
  tidak bisa lewat cara ini.
- Sebagian HP (terutama beberapa ROM Xiaomi/Samsung baru) memblokir perintah ini.
- Belum dikompilasi/diuji di perangkat saat dibuat.

## Build tanpa Android Studio (cukup HP)
1. Buat akun GitHub, buat repository baru (boleh private).
2. Upload semua isi folder ini (termasuk folder `.github`) ke repository itu.
3. Buka tab **Actions**, tunggu "Build APK" selesai (sekitar 5 menit).
4. Buka hasil build, unduh artifact **GameFilter-APK**, ekstrak, lalu pasang `app-debug.apk`.
