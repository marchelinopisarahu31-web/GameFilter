package com.example.gamefilter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin

private val Bg = Color(0xFF0F1017)
private val Panel = Color(0xFF1A1B26)
private val Tile = Color(0xFF232535)
private val TileOn = Color(0xFF343650)
private val Dim = Color(0xFF9A9DB3)
private val Accent = Color(0xFFEE2F4E)
private val AccentSoft = Color(0xFFFF6B82)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) {
                App()
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val st = remember { Prefs.load(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    var adjKey by remember { mutableStateOf("b") }
    var backend by remember { mutableStateOf("checking") }

    val cm = Engine.build(st.filter, st.intensity, st.adj)
    val cmd = cm.toSfCommand()

    LaunchedEffect(Unit) { backend = withContext(Dispatchers.IO) { Display.detect() } }
    LaunchedEffect(st.enabled, cmd, backend) {
        delay(40)
        withContext(Dispatchers.IO) { Display.applyState(st.enabled, cm) }
        Prefs.save(ctx, st)
    }

    val preset = Engine.presets.firstOrNull { it.id == st.filter } ?: Engine.presets[0]
    val statusText = when (backend) {
        "shizuku" -> "Shizuku connected"
        "root" -> "Root access"
        "shizuku-perm" -> "Shizuku is running. Tap to allow access."
        "none" -> "No Shizuku or root found. Tap to check again."
        else -> "Checking access..."
    }
    val statusOk = backend == "shizuku" || backend == "root"

    Column(
        Modifier.fillMaxSize().background(Bg).systemBarsPadding().padding(horizontal = 16.dp)
    ) {
        Row(Modifier.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(Tile).clickable { st.reset() },
                contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Close, "Reset", tint = Color.White)
            }
            Text("Game filter", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f).padding(start = 4.dp))
            Pill("Off", false) { st.enabled = false }
            Pill(if (st.enabled) "On" else "Apply", true, active = st.enabled) { st.enabled = true }
        }

        Text(statusText, color = if (statusOk) AccentSoft else Dim, fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 8.dp).clickable {
                if (backend == "shizuku-perm") Display.requestShizuku()
                Thread { backend = Display.detect() }.start()
            })

        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0xFF0A0B10)),
            contentAlignment = Alignment.Center) {
            Scene(Modifier.fillMaxSize().padding(14.dp).clip(RoundedCornerShape(12.dp)), cm)
            Text("Preview. The real effect covers the whole screen, games included.", color = Color.White,
                fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(10.dp)
                    .background(Color(0xD90F1017), RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 6.dp))
        }

        Column(Modifier.padding(top = 10.dp).fillMaxWidth().clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .background(Panel).padding(12.dp)) {
            if (tab == 0) {
                Text(preset.name, color = AccentSoft, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(preset.desc, color = Dim, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(Engine.presets) { p ->
                        val sel = p.id == st.filter
                        Column(Modifier.width(72.dp).clickable { st.filter = p.id },
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            Scene(Modifier.size(64.dp).clip(RoundedCornerShape(12.dp))
                                .border(2.dp, if (sel) Accent else Color.Transparent, RoundedCornerShape(12.dp)),
                                p.cm)
                            Text(p.name, color = if (sel) Color.White else Dim, fontSize = 11.sp,
                                maxLines = 1, modifier = Modifier.padding(top = 5.dp))
                        }
                    }
                }
                Text("Intensity ${st.intensity}%", color = Color.White, fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp))
                Ruler(st.intensity, 0, 300) { st.intensity = it }
            } else {
                val spec = Engine.adjSpecs.first { it.key == adjKey }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(Engine.adjSpecs) { a ->
                        val v = st.adj[a.key] ?: 0
                        val sel = a.key == adjKey
                        Column(Modifier.width(92.dp).height(60.dp).clip(RoundedCornerShape(14.dp))
                            .background(if (sel) TileOn else Tile)
                            .border(if (sel) BorderStroke(2.dp, Accent) else BorderStroke(0.dp, Color.Transparent), RoundedCornerShape(14.dp))
                            .clickable { adjKey = a.key },
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Text(a.label, color = if (sel) Color.White else Dim, fontSize = 13.sp)
                            Text((if (v > 0) "+" else "") + v, color = if (v != 0) AccentSoft else Dim,
                                fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                val cur = st.adj[spec.key] ?: 0
                Text((if (cur > 0) "+" else "") + cur, color = Color.White, fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp))
                Ruler(cur, spec.min, spec.max) { st.adj[spec.key] = it }
            }
        }

        Row(Modifier.fillMaxWidth().background(Panel).padding(bottom = 6.dp)) {
            BottomTab("Filters", Icons.Default.AutoAwesome, tab == 0, Modifier.weight(1f)) { tab = 0 }
            BottomTab("Adjust", Icons.Default.Tune, tab == 1, Modifier.weight(1f)) { tab = 1 }
        }
    }
}

@Composable
private fun Pill(text: String, primary: Boolean, active: Boolean = false, onClick: () -> Unit) {
    Box(Modifier.height(38.dp).clip(RoundedCornerShape(19.dp))
        .background(if (primary && (active || text == "Apply")) Accent else Tile)
        .clickable(onClick = onClick).padding(horizontal = 16.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun BottomTab(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
                      selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.padding(horizontal = 4.dp).clip(RoundedCornerShape(14.dp))
        .background(if (selected) Tile else Color.Transparent).clickable(onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, label, tint = if (selected) Color.White else Dim, modifier = Modifier.size(22.dp))
        Text(label, color = if (selected) Color.White else Dim, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

/** Penggaris geser seperti di editor media. */
@Composable
fun Ruler(value: Int, minV: Int, maxV: Int, onChange: (Int) -> Unit) {
    var f by remember { mutableFloatStateOf(value.toFloat()) }
    LaunchedEffect(value, minV, maxV) {
        if (f.roundToInt() != value) f = value.toFloat().coerceIn(minV.toFloat(), maxV.toFloat())
    }
    val onCh by rememberUpdatedState(onChange)
    val unit = with(LocalDensity.current) { 2.8.dp.toPx() }
    Canvas(Modifier.fillMaxWidth().height(40.dp).pointerInput(minV, maxV) {
        detectHorizontalDragGestures { change, dx ->
            change.consume()
            f = (f - dx / unit).coerceIn(minV.toFloat(), maxV.toFloat())
            onCh(f.roundToInt())
        }
    }) {
        val c = size.width / 2
        val lo = kotlin.math.max(minV, floor(f - c / unit).toInt())
        val hi = kotlin.math.min(maxV, ceil(f + c / unit).toInt())
        var i = lo
        while (i <= hi) {
            if (i % 2 == 0) {
                val x = c + (i - f) * unit
                val big = i % 10 == 0
                val half = (if (big) 13.dp else 7.dp).toPx()
                drawLine(if (big) Color(0xFF8B8EA8) else Color(0xFF4A4D66), Offset(x, size.height / 2 - half),
                    Offset(x, size.height / 2 + half), strokeWidth = 1.5.dp.toPx(), cap = StrokeCap.Round)
            }
            i++
        }
        drawLine(Accent, Offset(c, size.height / 2 - 17.dp.toPx()), Offset(c, size.height / 2 + 17.dp.toPx()),
            strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
    }
}

/** Gambar contoh (pemandangan) yang diberi matriks warna yang sama dengan yang dikirim ke layar. */
@Composable
fun Scene(modifier: Modifier, cm: CM) {
    val cf = remember(cm.toSfCommand()) { ColorFilter.colorMatrix(ColorMatrix(cm.toAndroid())) }
    Canvas(modifier) {
        val w = size.width; val h = size.height
        drawRect(brush = Brush.verticalGradient(
            listOf(Color(0xFF2B4A8A), Color(0xFFE98A5B), Color(0xFFF6D28A)), startY = 0f, endY = h * .65f),
            size = Size(w, h), colorFilter = cf)
        drawCircle(Color(0xFFFFE08A), radius = h * .16f, center = Offset(w * .72f, h * .5f), colorFilter = cf)
        fun hill(y: Float, amp: Float, ph: Float, col: Color) {
            val p = Path(); p.moveTo(0f, h)
            var x = 0f
            while (x <= w) { p.lineTo(x, y + sin(x / (w * .16f) + ph) * amp); x += w / 60f }
            p.lineTo(w, h); p.close()
            drawPath(p, col, colorFilter = cf)
        }
        hill(h * .60f, h * .05f, 1f, Color(0xFF5B6A9A))
        hill(h * .70f, h * .06f, 2.4f, Color(0xFF3E7A5A))
        hill(h * .82f, h * .05f, 4f, Color(0xFF1F5A3D))
        drawRect(Color(0xFF4A2F1D), Offset(w * .21f, h * .64f), Size(w * .015f, h * .17f), colorFilter = cf)
        drawCircle(Color(0xFFD8403A), radius = h * .09f, center = Offset(w * .22f, h * .61f), colorFilter = cf)
        drawCircle(Color(0xFFE8C53A), radius = h * .055f, center = Offset(w * .19f, h * .65f), colorFilter = cf)
    }
}
