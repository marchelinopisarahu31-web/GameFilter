package com.example.gamefilter

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Tombol di panel Quick Settings: nyalakan/matikan filter tanpa membuka app (berguna saat di dalam game). */
class FilterTile : TileService() {
    override fun onStartListening() = refresh()

    override fun onClick() {
        val s = Prefs.load(this)
        s.enabled = !s.enabled
        Prefs.save(this, s)
        Thread { Display.applyFromPrefs(applicationContext) }.start()
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.state = if (Prefs.load(this).enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.updateTile()
    }
}
