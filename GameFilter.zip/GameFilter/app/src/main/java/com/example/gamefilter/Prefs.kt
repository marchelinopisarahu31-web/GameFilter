package com.example.gamefilter

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class FilterState {
    var enabled by mutableStateOf(false)
    var filter by mutableStateOf("original")
    var intensity by mutableIntStateOf(100)
    val adj = mutableStateMapOf<String, Int>()

    fun reset() {
        filter = "original"; intensity = 100
        Engine.adjSpecs.forEach { adj[it.key] = 0 }
    }
}

object Prefs {
    fun load(ctx: Context): FilterState {
        val sp = ctx.getSharedPreferences("gf", Context.MODE_PRIVATE)
        val s = FilterState()
        s.enabled = sp.getBoolean("enabled", false)
        s.filter = sp.getString("filter", "original") ?: "original"
        s.intensity = sp.getInt("intensity", 100)
        Engine.adjSpecs.forEach { s.adj[it.key] = sp.getInt("adj_" + it.key, 0) }
        return s
    }

    fun save(ctx: Context, s: FilterState) {
        val e = ctx.getSharedPreferences("gf", Context.MODE_PRIVATE).edit()
        e.putBoolean("enabled", s.enabled).putString("filter", s.filter).putInt("intensity", s.intensity)
        Engine.adjSpecs.forEach { e.putInt("adj_" + it.key, s.adj[it.key] ?: 0) }
        e.apply()
    }
}
