package com.example.gamefilter

import java.util.Locale
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/** Matriks warna 3x3 + offset (nilai 0..1). Dipakai untuk preview di app dan untuk layar sungguhan. */
class CM(val a: FloatArray, val o: FloatArray) {

    /** Jalankan [n] setelah matriks ini. */
    infix fun then(n: CM): CM {
        val r = FloatArray(9)
        for (i in 0..2) for (j in 0..2) {
            var s = 0f
            for (k in 0..2) s += n.a[i * 3 + k] * a[k * 3 + j]
            r[i * 3 + j] = s
        }
        val off = FloatArray(3) { i ->
            var s = n.o[i]
            for (k in 0..2) s += n.a[i * 3 + k] * o[k]
            s
        }
        return CM(r, off)
    }

    /** k = 0 -> tanpa efek, 1 -> penuh, >1 -> berlebih. */
    fun mix(k: Float): CM {
        val r = FloatArray(9) { i ->
            val id = if (i % 4 == 0) 1f else 0f
            id + (a[i] - id) * k
        }
        return CM(r, FloatArray(3) { o[it] * k })
    }

    /** Format android.graphics.ColorMatrix / Compose ColorMatrix (4x5, offset 0..255). */
    fun toAndroid(): FloatArray = floatArrayOf(
        a[0], a[1], a[2], 0f, o[0] * 255f,
        a[3], a[4], a[5], 0f, o[1] * 255f,
        a[6], a[7], a[8], 0f, o[2] * 255f,
        0f, 0f, 0f, 1f, 0f
    )

    /** Perintah shell untuk SurfaceFlinger (matriks 4x4 urutan kolom). */
    fun toSfCommand(): String {
        val v = ArrayList<Float>(16)
        for (j in 0..2) { v.add(a[j]); v.add(a[3 + j]); v.add(a[6 + j]); v.add(0f) }
        v.add(o[0]); v.add(o[1]); v.add(o[2]); v.add(1f)
        val sb = StringBuilder("service call SurfaceFlinger 1015 i32 1")
        for (x in v) sb.append(" f ").append(String.format(Locale.US, "%.5f", x))
        return sb.toString()
    }

    companion object {
        val ID = CM(floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f), floatArrayOf(0f, 0f, 0f))
        const val RESET_COMMAND = "service call SurfaceFlinger 1015 i32 0"
    }
}

class Preset(val id: String, val name: String, val desc: String, val cm: CM)
class AdjSpec(val key: String, val label: String, val min: Int, val max: Int)

object Engine {
    private val LUM = floatArrayOf(.299f, .587f, .114f)
    private val Z3 = floatArrayOf(0f, 0f, 0f)

    fun scale(r: Float, g: Float, b: Float) = CM(floatArrayOf(r, 0f, 0f, 0f, g, 0f, 0f, 0f, b), Z3.copyOf())
    fun add(r: Float, g: Float, b: Float) = CM(CM.ID.a.copyOf(), floatArrayOf(r, g, b))
    fun mat(vararg v: Float) = CM(v.copyOf(9), Z3.copyOf())
    fun sat(s: Float): CM {
        val a = FloatArray(9)
        for (i in 0..2) for (j in 0..2) a[i * 3 + j] = (if (i == j) s else 0f) + (1 - s) * LUM[j]
        return CM(a, Z3.copyOf())
    }
    fun con(c: Float) = CM(scale(c, c, c).a, floatArrayOf(.5f * (1 - c), .5f * (1 - c), .5f * (1 - c)))
    fun hue(deg: Float): CM {
        val h = Math.toRadians(deg.toDouble())
        val c = cos(h).toFloat(); val s = sin(h).toFloat()
        return mat(
            .213f + c * .787f - s * .213f, .715f - c * .715f - s * .715f, .072f - c * .072f + s * .928f,
            .213f - c * .213f + s * .143f, .715f + c * .285f + s * .140f, .072f - c * .072f - s * .283f,
            .213f - c * .213f - s * .787f, .715f - c * .715f + s * .715f, .072f + c * .928f + s * .072f
        )
    }

    private val gray = sat(0f)

    val presets = listOf(
        Preset("original", "Original", "No change.", CM.ID),
        Preset("night", "Night Vision", "Lifts dark areas and shadows with a light green tint.",
            gray then scale(.45f, 1f, .55f) then scale(1.5f, 1.5f, 1.5f)),
        Preset("hunter", "Hunter", "Boosts green and yellow contrast so movement in the grass stands out.",
            sat(1.5f) then scale(.95f, 1.12f, .85f) then con(1.2f)),
        Preset("ultra", "Ultra-Clear", "Stronger contrast and color for a sharper look.",
            con(1.25f) then sat(1.3f)),
        Preset("invert", "Invert", "Inverts every color.",
            CM(scale(-1f, -1f, -1f).a, floatArrayOf(1f, 1f, 1f))),
        Preset("mono", "Monochrome", "Grayscale to read shapes and light.", gray),
        Preset("deut", "Red-green", "Color-vision filter (deuteranomaly).",
            mat(.367f, .861f, -.228f, .280f, .673f, .047f, -.012f, .043f, .969f)),
        Preset("trit", "Blue-yellow", "Color-vision filter (tritanomaly).",
            mat(1.256f, -.077f, -.179f, -.078f, .931f, .148f, .005f, .691f, .304f)),
        Preset("prot", "Protanomaly", "Color-vision filter (protanomaly).",
            mat(.152f, 1.053f, -.205f, .115f, .786f, .099f, -.004f, -.048f, 1.052f)),
        Preset("vivid", "Vivid", "Rich, saturated colors.", sat(1.4f) then con(1.1f)),
        Preset("warm", "Warm", "Warmer tone.", scale(1.06f, 1f, .9f) then add(.03f, 0f, -.024f)),
        Preset("cool", "Cool", "Cooler tone.", scale(.9f, 1f, 1.08f) then add(-.016f, 0f, .03f)),
        Preset("noir", "Noir", "High-contrast black and white.", gray then con(1.45f) then add(-.047f, -.047f, -.047f)),
        Preset("fade", "Fade", "Washed-out, lifted blacks.", sat(.8f) then con(.82f) then add(.086f, .086f, .086f)),
        Preset("sepia", "Sepia", "Old photo tone.",
            mat(.393f, .769f, .189f, .349f, .686f, .168f, .272f, .534f, .131f)),
        Preset("drama", "Drama", "Heavy contrast, muted color.", sat(.8f) then con(1.35f) then add(-.039f, -.039f, -.039f))
    )

    val adjSpecs = listOf(
        AdjSpec("b", "Brightness", -300, 300),
        AdjSpec("c", "Contrast", -300, 300),
        AdjSpec("s", "Saturation", -300, 300),
        AdjSpec("e", "Exposure", -300, 300),
        AdjSpec("v", "Vibrance", -300, 300),
        AdjSpec("t", "Warmth", -300, 300),
        AdjSpec("n", "Tint", -300, 300),
        AdjSpec("u", "Hue", -180, 180),
        AdjSpec("f", "Fade", 0, 300)
    )

    /** Gabungkan filter (dengan intensitas 0..300 %) dan semua pengaturan menjadi satu matriks. */
    fun build(filter: String, intensity: Int, adj: Map<String, Int>): CM {
        val p = presets.firstOrNull { it.id == filter } ?: presets[0]
        var m = p.cm.mix(intensity / 100f)
        fun v(k: String) = adj[k] ?: 0
        if (v("e") != 0) { val x = 2f.pow(v("e") / 100f); m = m then scale(x, x, x) }
        if (v("u") != 0) m = m then hue(v("u").toFloat())
        val s = (1f + v("s") / 100f) * (1f + v("v") / 200f)
        if (s != 1f) m = m then sat(s)
        if (v("t") != 0 || v("n") != 0) {
            val w = v("t") * .3f / 255f; val ti = v("n") * .3f / 255f
            m = m then add(w + ti * .5f, -ti, -w + ti * .5f)
        }
        if (v("b") != 0) { val d = v("b") * 1.28f / 255f; m = m then add(d, d, d) }
        if (v("c") != 0) {
            val c = if (v("c") >= 0) 1f + v("c") / 100f else 1f / (1f + (-v("c")) / 100f)
            m = m then con(c)
        }
        if (v("f") != 0) { val q = v("f") * .3f / 255f; m = m then CM(scale(1 - q, 1 - q, 1 - q).a, floatArrayOf(q, q, q)) }
        return m
    }
}
