package com.example.gamefilter

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/**
 * Menerapkan matriks warna ke SELURUH layar (termasuk game) lewat SurfaceFlinger.
 * Perlu hak shell: Shizuku (disarankan, tanpa root) atau root (su).
 */
object Display {
    @Volatile var backend: String = "unknown" // shizuku | shizuku-perm | root | none | unknown

    private fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun shizukuRunning(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    private fun rootOk(): Boolean = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.contains("uid=0")
    } catch (e: Throwable) { false }

    fun detect(): String {
        backend = when {
            shizukuReady() -> "shizuku"
            shizukuRunning() -> "shizuku-perm"
            rootOk() -> "root"
            else -> "none"
        }
        return backend
    }

    fun requestShizuku() {
        try { Shizuku.requestPermission(1001) } catch (e: Throwable) { }
    }

    private fun exec(cmd: String): Boolean {
        if (shizukuReady()) {
            try {
                val m = Shizuku::class.java.getDeclaredMethod(
                    "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
                )
                m.isAccessible = true
                val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
                p.waitFor()
                return p.exitValue() == 0
            } catch (e: Throwable) { /* coba root */ }
        }
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            p.waitFor()
            p.exitValue() == 0
        } catch (e: Throwable) { false }
    }

    fun applyState(enabled: Boolean, cm: CM): Boolean {
        if (backend == "unknown") detect()
        if (backend == "none" || backend == "shizuku-perm") return false
        return exec(if (enabled) cm.toSfCommand() else CM.RESET_COMMAND)
    }

    fun applyFromPrefs(ctx: Context) {
        val s = Prefs.load(ctx)
        applyState(s.enabled, Engine.build(s.filter, s.intensity, s.adj))
    }
}
